package com.hotelease.helpers;

import com.hotelease.models.User;
import com.hotelease.models.Hotel;

import java.util.ArrayList;
import java.util.List;

public class SessionManager {
    private static SessionManager instance;
    private User currentUser;
    private List<Hotel> favorites;
    
    private SessionManager() {
        favorites = new ArrayList<>();
    }
    
    public static SessionManager getInstance() {
        if (instance == null) {
            instance = new SessionManager();
        }
        return instance;
    }
    
    public void setCurrentUser(User user) {
        this.currentUser = user;
    }
    
    public User getCurrentUser() {
        return currentUser;
    }
    
    public boolean isLoggedIn() {
        return currentUser != null;
    }
    
    public boolean isAdmin() {
        return currentUser != null && currentUser.isAdmin();
    }
    
    public void logout() {
        currentUser = null;
        favorites.clear();
    }
    
    public void addFavorite(Hotel hotel) {
        if (!isFavorite(hotel)) {
            favorites.add(hotel);
        }
    }
    
    public void removeFavorite(Hotel hotel) {
        favorites.removeIf(h -> h.getId().equals(hotel.getId()));
    }
    
    public boolean isFavorite(Hotel hotel) {
        return favorites.stream().anyMatch(h -> h.getId().equals(hotel.getId()));
    }
    
    public List<Hotel> getFavorites() {
        return new ArrayList<>(favorites);
    }
}
