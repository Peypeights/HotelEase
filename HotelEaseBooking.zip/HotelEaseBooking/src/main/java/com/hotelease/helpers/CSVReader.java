package com.hotelease.helpers;

import com.hotelease.models.Hotel;
import com.hotelease.models.Booking;

import java.io.*;
import java.nio.file.*;
import java.util.ArrayList;
import java.util.List;

public class CSVReader {
    
    private static final String HOTELS_FILE = "data/hotels.csv";
    private static final String BOOKINGS_FILE = "data/bookings.csv";
    
    static {
        ensureDataFilesExist();
    }
    
    private static void ensureDataFilesExist() {
        try {
            File dataDir = new File("data");
            if (!dataDir.exists()) {
                dataDir.mkdirs();
            }
            
            File hotelsFile = new File(HOTELS_FILE);
            if (!hotelsFile.exists()) {
                try (PrintWriter out = new PrintWriter(new FileWriter(hotelsFile))) {
                    out.println("id,name,location,price,moodCategory,imageUrl");
                    out.println("H001,Makati Diamond Residences,Makati City Metro Manila,4500.00,Urban Comfort,https://images.unsplash.com/photo-1566073771259-6a8506099945?w=800");
                    out.println("H002,BGC The Fort Premium Suites,Bonifacio Global City Taguig,5200.00,Urban Comfort,https://images.unsplash.com/photo-1551882547-ff40c63fe5fa?w=800");
                    out.println("H003,Manila Bay View Hotel,Roxas Boulevard Manila,3800.00,Urban Comfort,https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?w=800");
                    out.println("H004,Ortigas Center Executive Tower,Pasig City Metro Manila,4200.00,Urban Comfort,https://images.unsplash.com/photo-1520250497591-112f2f40a3f4?w=800");
                    out.println("H005,Quezon City Grand Plaza,Quezon City Metro Manila,3500.00,Urban Comfort,https://images.unsplash.com/photo-1455587734955-081b22074882?w=800");
                    out.println("H006,Boracay White Beach Resort,Boracay Island Aklan,6800.00,Coastal Escape,https://images.unsplash.com/photo-1559827260-dc66d52bef19?w=800");
                    out.println("H007,El Nido Paradise Cove,El Nido Palawan,7500.00,Coastal Escape,https://images.unsplash.com/photo-1571896349842-33c89424de2d?w=800");
                    out.println("H008,Siargao Island Surf Resort,Siargao Surigao del Norte,5500.00,Coastal Escape,https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?w=800");
                    out.println("H009,Cebu Mactan Beach Hotel,Lapu-Lapu City Cebu,4800.00,Coastal Escape,https://images.unsplash.com/photo-1574168737175-a44c7e4d2a32?w=800");
                    out.println("H010,Batangas Anilao Dive Resort,Anilao Batangas,3900.00,Coastal Escape,https://images.unsplash.com/photo-1540541338287-41700207dee6?w=800");
                    out.println("H011,Tagaytay Taal Vista Lodge,Tagaytay City Cavite,4000.00,Nature Retreat,https://images.unsplash.com/photo-1571003123894-1f0594d2b5d9?w=800");
                    out.println("H012,Baguio Pine Hills Retreat,Baguio City Benguet,3600.00,Nature Retreat,https://images.unsplash.com/photo-1587061949409-02df41d5e562?w=800");
                    out.println("H013,Sagada Mountain Lodge,Sagada Mountain Province,3200.00,Nature Retreat,https://images.unsplash.com/photo-1596394516093-501ba68a0ba6?w=800");
                    out.println("H014,Bohol Chocolate Hills Vista,Carmen Bohol,4500.00,Nature Retreat,https://images.unsplash.com/photo-1551918120-9739cb430c6d?w=800");
                    out.println("H015,Camiguin Volcano View Resort,Camiguin Island,3800.00,Nature Retreat,https://images.unsplash.com/photo-1584132967334-10e028bd69f7?w=800");
                }
            }
            
            File bookingsFile = new File(BOOKINGS_FILE);
            if (!bookingsFile.exists()) {
                try (PrintWriter out = new PrintWriter(new FileWriter(bookingsFile))) {
                    out.println("bookingId,hotelId,hotelName,customerName,customerContact,checkInDate,checkOutDate,numberOfNights,totalPrice");
                }
            }
        } catch (IOException e) {
            System.err.println("Error ensuring data files exist: " + e.getMessage());
        }
    }
    
    public static List<Hotel> loadHotels(String filePath) {
        List<Hotel> hotels = new ArrayList<>();
        File file = new File(HOTELS_FILE);
        
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            br.readLine();
            
            while ((line = br.readLine()) != null) {
                String[] data = line.split(",");
                if (data.length >= 6) {
                    String id = data[0].trim();
                    String name = data[1].trim();
                    String location = data[2].trim();
                    double price = Double.parseDouble(data[3].trim());
                    String moodCategory = data[4].trim();
                    String imageUrl = data[5].trim();
                    
                    hotels.add(new Hotel(id, name, location, price, moodCategory, imageUrl));
                }
            }
        } catch (Exception e) {
            System.err.println("Error loading hotels: " + e.getMessage());
            e.printStackTrace();
        }
        
        return hotels;
    }
    
    public static List<Booking> loadBookings(String filePath) {
        List<Booking> bookings = new ArrayList<>();
        File file = new File(BOOKINGS_FILE);
        
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            br.readLine();
            
            while ((line = br.readLine()) != null) {
                String[] data = line.split(",");
                if (data.length >= 9) {
                    bookings.add(new Booking(
                        data[0].trim(),
                        data[1].trim(),
                        data[2].trim(),
                        data[3].trim(),
                        data[4].trim(),
                        data[5].trim(),
                        data[6].trim(),
                        Integer.parseInt(data[7].trim()),
                        Double.parseDouble(data[8].trim())
                    ));
                }
            }
        } catch (Exception e) {
            System.err.println("Error loading bookings: " + e.getMessage());
        }
        
        return bookings;
    }
    
    public static void saveBooking(Booking booking) {
        try {
            File file = new File(BOOKINGS_FILE);
            boolean fileExists = file.exists();
            
            if (!fileExists) {
                file.getParentFile().mkdirs();
            }
            
            try (FileWriter fw = new FileWriter(file, true);
                 BufferedWriter bw = new BufferedWriter(fw);
                 PrintWriter out = new PrintWriter(bw)) {
                
                if (!fileExists || file.length() == 0) {
                    out.println("bookingId,hotelId,hotelName,customerName,customerContact,checkInDate,checkOutDate,numberOfNights,totalPrice");
                }
                
                out.println(booking.toCSV());
            }
        } catch (IOException e) {
            System.err.println("Error saving booking: " + e.getMessage());
        }
    }
    
    public static void saveHotel(Hotel hotel) {
        try {
            File file = new File(HOTELS_FILE);
            boolean fileExists = file.exists();
            
            if (!fileExists) {
                file.getParentFile().mkdirs();
            }
            
            try (FileWriter fw = new FileWriter(file, true);
                 BufferedWriter bw = new BufferedWriter(fw);
                 PrintWriter out = new PrintWriter(bw)) {
                
                if (!fileExists || file.length() == 0) {
                    out.println("id,name,location,price,moodCategory,imageUrl");
                }
                
                out.println(hotel.getId() + "," + hotel.getName() + "," + hotel.getLocation() + "," + 
                           hotel.getPrice() + "," + hotel.getMoodCategory() + "," + hotel.getImageUrl());
            }
        } catch (IOException e) {
            System.err.println("Error saving hotel: " + e.getMessage());
        }
    }
    
    public static void removeHotel(String hotelId) {
        List<Hotel> hotels = loadHotels(HOTELS_FILE);
        
        try {
            File file = new File(HOTELS_FILE);
            
            try (FileWriter fw = new FileWriter(file);
                 BufferedWriter bw = new BufferedWriter(fw);
                 PrintWriter out = new PrintWriter(bw)) {
                
                out.println("id,name,location,price,moodCategory,imageUrl");
                
                for (Hotel hotel : hotels) {
                    if (!hotel.getId().equals(hotelId)) {
                        out.println(hotel.getId() + "," + hotel.getName() + "," + hotel.getLocation() + "," + 
                                   hotel.getPrice() + "," + hotel.getMoodCategory() + "," + hotel.getImageUrl());
                    }
                }
            }
        } catch (IOException e) {
            System.err.println("Error removing hotel: " + e.getMessage());
        }
    }
}
