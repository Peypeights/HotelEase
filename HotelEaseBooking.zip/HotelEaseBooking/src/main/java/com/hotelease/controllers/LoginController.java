package com.hotelease.controllers;

import com.hotelease.models.User;
import com.hotelease.helpers.SessionManager;
import com.hotelease.helpers.NavigationHelper;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.PasswordField;

public class LoginController {
    
    @FXML private TextField usernameField;
    @FXML private PasswordField passwordField;
    @FXML private Label errorLabel;
    
    @FXML
    public void handleAdminLogin(ActionEvent event) {
        String username = usernameField.getText().trim();
        String password = passwordField.getText().trim();
        
        if (username.equals("admin") && password.equals("Admin123")) {
            User admin = new User(username, password, "admin");
            SessionManager.getInstance().setCurrentUser(admin);
            NavigationHelper.navigateTo("/views/MainMenu.fxml", event);
        } else {
            errorLabel.setText("Invalid admin credentials!");
        }
    }
    
    @FXML
    public void handleGuestLogin(ActionEvent event) {
        User guest = new User("guest", "", "guest");
        SessionManager.getInstance().setCurrentUser(guest);
        NavigationHelper.navigateTo("/views/MainMenu.fxml", event);
    }
}
