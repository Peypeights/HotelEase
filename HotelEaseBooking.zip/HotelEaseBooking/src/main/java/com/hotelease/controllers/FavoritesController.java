package com.hotelease.controllers;

import com.hotelease.models.Hotel;
import com.hotelease.helpers.SessionManager;
import com.hotelease.helpers.NavigationHelper;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.layout.VBox;
import javafx.scene.layout.HBox;
import javafx.scene.text.Text;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.image.ImageView;
import javafx.scene.image.Image;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.Node;

import java.util.List;

public class FavoritesController {
    
    @FXML private VBox favoritesContainer;
    
    @FXML
    public void initialize() {
        loadFavorites();
    }
    
    private void loadFavorites() {
        favoritesContainer.getChildren().clear();
        
        List<Hotel> favorites = SessionManager.getInstance().getFavorites();
        
        if (favorites.isEmpty()) {
            Text noFavorites = new Text("No favorites yet. Start exploring hotels!");
            noFavorites.setStyle("-fx-fill: #888888; -fx-font-size: 16px;");
            favoritesContainer.getChildren().add(noFavorites);
            return;
        }
        
        for (Hotel hotel : favorites) {
            HBox favoriteCard = createFavoriteCard(hotel);
            favoritesContainer.getChildren().add(favoriteCard);
        }
    }
    
    private HBox createFavoriteCard(Hotel hotel) {
        HBox card = new HBox(20);
        card.setAlignment(Pos.CENTER_LEFT);
        card.setStyle("-fx-background-color: #2a2a2a; -fx-background-radius: 10px; -fx-padding: 20px;");
        card.setPrefHeight(150);
        
        ImageView imageView = new ImageView();
        try {
            Image image = new Image(hotel.getImageUrl(), true);
            imageView.setImage(image);
        } catch (Exception e) {
            System.err.println("Error loading image: " + e.getMessage());
        }
        imageView.setFitWidth(200);
        imageView.setFitHeight(120);
        imageView.setPreserveRatio(true);
        imageView.setStyle("-fx-background-radius: 8px;");
        
        VBox info = new VBox(8);
        info.setAlignment(Pos.CENTER_LEFT);
        HBox.setHgrow(info, javafx.scene.layout.Priority.ALWAYS);
        
        Text name = new Text(hotel.getName());
        name.setStyle("-fx-fill: #ffffff; -fx-font-size: 20px; -fx-font-weight: bold;");
        
        Text location = new Text("📍 " + hotel.getLocation());
        location.setStyle("-fx-fill: #cccccc; -fx-font-size: 14px;");
        
        Text category = new Text("Category: " + hotel.getMoodCategory());
        category.setStyle("-fx-fill: #888888; -fx-font-size: 13px;");
        
        Text price = new Text("₱" + String.format("%.2f", hotel.getPrice()) + " / night");
        price.setStyle("-fx-fill: #66bb6a; -fx-font-size: 16px; -fx-font-weight: bold;");
        
        info.getChildren().addAll(name, location, category, price);
        
        VBox actions = new VBox(10);
        actions.setAlignment(Pos.CENTER);
        
        Button viewButton = new Button("View Details");
        viewButton.setStyle("-fx-background-color: #4da6ff; -fx-text-fill: white; -fx-font-size: 13px; -fx-background-radius: 5px; -fx-padding: 8px 20px; -fx-cursor: hand;");
        viewButton.setOnAction(e -> viewHotelDetails(hotel, e));
        
        Button removeButton = new Button("Remove");
        removeButton.setStyle("-fx-background-color: #ff4444; -fx-text-fill: white; -fx-font-size: 13px; -fx-background-radius: 5px; -fx-padding: 8px 20px; -fx-cursor: hand;");
        removeButton.setOnAction(e -> {
            SessionManager.getInstance().removeFavorite(hotel);
            loadFavorites();
        });
        
        actions.getChildren().addAll(viewButton, removeButton);
        
        card.getChildren().addAll(imageView, info, actions);
        
        return card;
    }
    
    private void viewHotelDetails(Hotel hotel, ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/views/HotelDetails.fxml"));
            Parent root = loader.load();
            
            HotelDetailsController controller = loader.getController();
            controller.receiveData(hotel);
            
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
        } catch (Exception e) {
            System.err.println("Navigation error: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    @FXML
    public void handleBack(ActionEvent event) {
        NavigationHelper.navigateTo("/views/MainMenu.fxml", event);
    }
}
