package com.hotelease.controllers;

import com.hotelease.models.Hotel;
import com.hotelease.models.Booking;
import com.hotelease.helpers.SessionManager;
import com.hotelease.helpers.NavigationHelper;
import com.hotelease.helpers.CSVReader;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.scene.image.ImageView;
import javafx.scene.image.Image;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.UUID;

public class HotelDetailsController implements NavigationHelper.DataReceiver {
    
    @FXML private ImageView hotelImage;
    @FXML private Text hotelName;
    @FXML private Text hotelLocation;
    @FXML private Text hotelMood;
    @FXML private Text hotelPrice;
    @FXML private Button favoriteButton;
    @FXML private VBox bookingForm;
    @FXML private TextField customerNameField;
    @FXML private TextField customerContactField;
    @FXML private DatePicker checkInDate;
    @FXML private DatePicker checkOutDate;
    @FXML private Text nightsLabel;
    @FXML private Text totalPriceLabel;
    @FXML private Label bookingErrorLabel;
    
    private Hotel currentHotel;
    
    @Override
    public void receiveData(Object data) {
        this.currentHotel = (Hotel) data;
        displayHotelDetails();
    }
    
    @FXML
    public void initialize() {
        if (checkInDate != null && checkOutDate != null) {
            checkInDate.valueProperty().addListener((obs, oldVal, newVal) -> calculateNights());
            checkOutDate.valueProperty().addListener((obs, oldVal, newVal) -> calculateNights());
        }
    }
    
    private void displayHotelDetails() {
        hotelName.setText(currentHotel.getName());
        hotelLocation.setText(currentHotel.getLocation());
        hotelMood.setText(currentHotel.getMoodCategory());
        hotelPrice.setText("₱" + String.format("%.2f", currentHotel.getPrice()));
        
        try {
            Image image = new Image(currentHotel.getImageUrl(), true);
            hotelImage.setImage(image);
        } catch (Exception e) {
            System.err.println("Error loading image: " + e.getMessage());
        }
        
        updateFavoriteButton();
    }
    
    private void updateFavoriteButton() {
        if (SessionManager.getInstance().isFavorite(currentHotel)) {
            favoriteButton.setText("Remove from Favorites");
            favoriteButton.setStyle("-fx-background-color: #888888; -fx-text-fill: white; -fx-font-size: 14px; -fx-background-radius: 5px; -fx-padding: 12px 25px; -fx-font-weight: bold; -fx-cursor: hand;");
        } else {
            favoriteButton.setText("Add to Favorites");
            favoriteButton.setStyle("-fx-background-color: #ff6b6b; -fx-text-fill: white; -fx-font-size: 14px; -fx-background-radius: 5px; -fx-padding: 12px 25px; -fx-font-weight: bold; -fx-cursor: hand;");
        }
    }
    
    @FXML
    public void handleToggleFavorite(ActionEvent event) {
        if (SessionManager.getInstance().isFavorite(currentHotel)) {
            SessionManager.getInstance().removeFavorite(currentHotel);
        } else {
            SessionManager.getInstance().addFavorite(currentHotel);
        }
        updateFavoriteButton();
    }
    
    @FXML
    public void handleBookNow(ActionEvent event) {
        bookingForm.setVisible(true);
        bookingErrorLabel.setText("");
    }
    
    @FXML
    public void handleCancelBooking(ActionEvent event) {
        bookingForm.setVisible(false);
        clearBookingForm();
    }
    
    private void calculateNights() {
        LocalDate checkIn = checkInDate.getValue();
        LocalDate checkOut = checkOutDate.getValue();
        
        if (checkIn != null && checkOut != null && checkOut.isAfter(checkIn)) {
            long nights = ChronoUnit.DAYS.between(checkIn, checkOut);
            double totalPrice = nights * currentHotel.getPrice();
            
            nightsLabel.setText(nights + " night" + (nights > 1 ? "s" : ""));
            totalPriceLabel.setText("₱" + String.format("%.2f", totalPrice));
        } else {
            nightsLabel.setText("0 nights");
            totalPriceLabel.setText("₱0.00");
        }
    }
    
    @FXML
    public void handleConfirmBooking(ActionEvent event) {
        String name = customerNameField.getText().trim();
        String contact = customerContactField.getText().trim();
        LocalDate checkIn = checkInDate.getValue();
        LocalDate checkOut = checkOutDate.getValue();
        
        if (name.isEmpty() || contact.isEmpty()) {
            bookingErrorLabel.setText("Please fill in all fields");
            return;
        }
        
        if (checkIn == null || checkOut == null) {
            bookingErrorLabel.setText("Please select check-in and check-out dates");
            return;
        }
        
        if (!checkOut.isAfter(checkIn)) {
            bookingErrorLabel.setText("Check-out date must be after check-in date");
            return;
        }
        
        long nights = ChronoUnit.DAYS.between(checkIn, checkOut);
        double totalPrice = nights * currentHotel.getPrice();
        
        String bookingId = "B" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
        
        Booking booking = new Booking(
            bookingId,
            currentHotel.getId(),
            currentHotel.getName(),
            name,
            contact,
            checkIn.toString(),
            checkOut.toString(),
            (int) nights,
            totalPrice
        );
        
        CSVReader.saveBooking(booking);
        
        bookingErrorLabel.setStyle("-fx-text-fill: #66bb6a;");
        bookingErrorLabel.setText("Booking confirmed! ID: " + bookingId);
        
        customerNameField.setDisable(true);
        customerContactField.setDisable(true);
        checkInDate.setDisable(true);
        checkOutDate.setDisable(true);
    }
    
    private void clearBookingForm() {
        customerNameField.clear();
        customerContactField.clear();
        checkInDate.setValue(null);
        checkOutDate.setValue(null);
        nightsLabel.setText("0 nights");
        totalPriceLabel.setText("₱0.00");
        bookingErrorLabel.setText("");
        
        customerNameField.setDisable(false);
        customerContactField.setDisable(false);
        checkInDate.setDisable(false);
        checkOutDate.setDisable(false);
    }
    
    @FXML
    public void handleBack(ActionEvent event) {
        NavigationHelper.navigateTo("/views/MoodSelection.fxml", event);
    }
}
