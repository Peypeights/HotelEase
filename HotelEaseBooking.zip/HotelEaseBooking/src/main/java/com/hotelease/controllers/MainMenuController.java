package com.hotelease.controllers;

import com.hotelease.helpers.SessionManager;
import com.hotelease.helpers.NavigationHelper;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;

public class MainMenuController {
    
    @FXML private Label welcomeLabel;
    @FXML private Button adminButton;
    
    @FXML
    public void initialize() {
        SessionManager session = SessionManager.getInstance();
        
        if (session.isLoggedIn()) {
            String username = session.getCurrentUser().getUsername();
            welcomeLabel.setText("Welcome, " + username + "!");
            
            if (session.isAdmin()) {
                adminButton.setVisible(true);
            }
        }
    }
    
    @FXML
    public void handleBrowseByMood(ActionEvent event) {
        NavigationHelper.navigateTo("/views/MoodSelection.fxml", event);
    }
    
    @FXML
    public void handleFavorites(ActionEvent event) {
        NavigationHelper.navigateTo("/views/Favorites.fxml", event);
    }
    
    @FXML
    public void handleAdminPanel(ActionEvent event) {
        NavigationHelper.navigateTo("/views/Admin.fxml", event);
    }
    
    @FXML
    public void handleLogout(ActionEvent event) {
        SessionManager.getInstance().logout();
        NavigationHelper.navigateTo("/views/Login.fxml", event);
    }
}
