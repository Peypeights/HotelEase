package com.hotelease.controllers;

import com.hotelease.models.Hotel;
import com.hotelease.models.Booking;
import com.hotelease.helpers.CSVReader;
import com.hotelease.helpers.NavigationHelper;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.scene.layout.HBox;
import javafx.scene.text.Text;
import javafx.geometry.Insets;
import javafx.geometry.Pos;

import java.util.List;

public class AdminController {
    
    @FXML private VBox bookingsContainer;
    @FXML private VBox hotelsContainer;
    @FXML private TextField hotelIdField;
    @FXML private TextField hotelNameField;
    @FXML private TextField hotelLocationField;
    @FXML private TextField hotelPriceField;
    @FXML private ComboBox<String> hotelMoodCombo;
    @FXML private TextField hotelImageField;
    @FXML private Label addHotelMessage;
    
    @FXML
    public void initialize() {
        loadBookings();
        loadHotels();
    }
    
    private void loadBookings() {
        bookingsContainer.getChildren().clear();
        
        List<Booking> bookings = CSVReader.loadBookings("/data/bookings.csv");
        
        if (bookings.isEmpty()) {
            Text noBookings = new Text("No bookings yet");
            noBookings.setStyle("-fx-fill: #888888; -fx-font-size: 16px;");
            bookingsContainer.getChildren().add(noBookings);
            return;
        }
        
        for (Booking booking : bookings) {
            VBox bookingCard = createBookingCard(booking);
            bookingsContainer.getChildren().add(bookingCard);
        }
    }
    
    private VBox createBookingCard(Booking booking) {
        VBox card = new VBox(10);
        card.setStyle("-fx-background-color: #2a2a2a; -fx-background-radius: 10px; -fx-padding: 20px;");
        
        Text bookingId = new Text("Booking ID: " + booking.getBookingId());
        bookingId.setStyle("-fx-fill: #4da6ff; -fx-font-size: 16px; -fx-font-weight: bold;");
        
        Text hotelName = new Text("Hotel: " + booking.getHotelName());
        hotelName.setStyle("-fx-fill: #ffffff; -fx-font-size: 14px;");
        
        Text customer = new Text("Customer: " + booking.getCustomerName());
        customer.setStyle("-fx-fill: #cccccc; -fx-font-size: 13px;");
        
        Text contact = new Text("Contact: " + booking.getCustomerContact());
        contact.setStyle("-fx-fill: #cccccc; -fx-font-size: 13px;");
        
        Text dates = new Text("Check-in: " + booking.getCheckInDate() + " | Check-out: " + booking.getCheckOutDate());
        dates.setStyle("-fx-fill: #cccccc; -fx-font-size: 13px;");
        
        Text nights = new Text("Duration: " + booking.getNumberOfNights() + " night(s)");
        nights.setStyle("-fx-fill: #888888; -fx-font-size: 13px;");
        
        Text total = new Text("Total: ₱" + String.format("%.2f", booking.getTotalPrice()));
        total.setStyle("-fx-fill: #66bb6a; -fx-font-size: 15px; -fx-font-weight: bold;");
        
        card.getChildren().addAll(bookingId, hotelName, customer, contact, dates, nights, total);
        
        return card;
    }
    
    private void loadHotels() {
        hotelsContainer.getChildren().clear();
        
        List<Hotel> hotels = CSVReader.loadHotels("/data/hotels.csv");
        
        for (Hotel hotel : hotels) {
            HBox hotelCard = createHotelManagementCard(hotel);
            hotelsContainer.getChildren().add(hotelCard);
        }
    }
    
    private HBox createHotelManagementCard(Hotel hotel) {
        HBox card = new HBox(15);
        card.setAlignment(Pos.CENTER_LEFT);
        card.setStyle("-fx-background-color: #2a2a2a; -fx-background-radius: 8px; -fx-padding: 15px;");
        
        VBox info = new VBox(5);
        info.setAlignment(Pos.CENTER_LEFT);
        HBox.setHgrow(info, javafx.scene.layout.Priority.ALWAYS);
        
        Text name = new Text(hotel.getName());
        name.setStyle("-fx-fill: #ffffff; -fx-font-size: 16px; -fx-font-weight: bold;");
        
        Text details = new Text(hotel.getLocation() + " | " + hotel.getMoodCategory() + " | ₱" + hotel.getPrice());
        details.setStyle("-fx-fill: #cccccc; -fx-font-size: 13px;");
        
        Text id = new Text("ID: " + hotel.getId());
        id.setStyle("-fx-fill: #888888; -fx-font-size: 12px;");
        
        info.getChildren().addAll(name, details, id);
        
        Button removeButton = new Button("Remove");
        removeButton.setStyle("-fx-background-color: #ff4444; -fx-text-fill: white; -fx-font-size: 12px; -fx-background-radius: 5px; -fx-padding: 8px 20px; -fx-cursor: hand;");
        removeButton.setOnAction(e -> {
            CSVReader.removeHotel(hotel.getId());
            loadHotels();
        });
        
        card.getChildren().addAll(info, removeButton);
        
        return card;
    }
    
    @FXML
    public void handleAddHotel(ActionEvent event) {
        String id = hotelIdField.getText().trim();
        String name = hotelNameField.getText().trim();
        String location = hotelLocationField.getText().trim();
        String priceStr = hotelPriceField.getText().trim();
        String mood = hotelMoodCombo.getValue();
        String imageUrl = hotelImageField.getText().trim();
        
        if (id.isEmpty() || name.isEmpty() || location.isEmpty() || priceStr.isEmpty() || mood == null || imageUrl.isEmpty()) {
            addHotelMessage.setStyle("-fx-text-fill: #ff4444;");
            addHotelMessage.setText("Please fill in all fields");
            return;
        }
        
        try {
            double price = Double.parseDouble(priceStr);
            Hotel newHotel = new Hotel(id, name, location, price, mood, imageUrl);
            CSVReader.saveHotel(newHotel);
            
            addHotelMessage.setStyle("-fx-text-fill: #66bb6a;");
            addHotelMessage.setText("Hotel added successfully!");
            
            hotelIdField.clear();
            hotelNameField.clear();
            hotelLocationField.clear();
            hotelPriceField.clear();
            hotelMoodCombo.setValue(null);
            hotelImageField.clear();
            
            loadHotels();
        } catch (NumberFormatException e) {
            addHotelMessage.setStyle("-fx-text-fill: #ff4444;");
            addHotelMessage.setText("Invalid price format");
        }
    }
    
    @FXML
    public void handleBack(ActionEvent event) {
        NavigationHelper.navigateTo("/views/MainMenu.fxml", event);
    }
}
