package com.hotelease.controllers;

import com.hotelease.models.Hotel;
import com.hotelease.helpers.CSVReader;
import com.hotelease.helpers.NavigationHelper;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.layout.VBox;
import javafx.scene.layout.HBox;
import javafx.scene.text.Text;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.image.ImageView;
import javafx.scene.image.Image;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.Node;

import java.util.List;
import java.util.stream.Collectors;

public class HotelListController implements NavigationHelper.DataReceiver {
    
    @FXML private VBox hotelContainer;
    @FXML private Text moodTitle;
    
    private String selectedMood;
    private List<Hotel> hotels;
    
    @Override
    public void receiveData(Object data) {
        this.selectedMood = (String) data;
        loadHotels();
    }
    
    private void loadHotels() {
        List<Hotel> allHotels = CSVReader.loadHotels("/data/hotels.csv");
        hotels = allHotels.stream()
                .filter(h -> h.getMoodCategory().equals(selectedMood))
                .collect(Collectors.toList());
        
        moodTitle.setText(selectedMood + " Hotels");
        displayHotels();
    }
    
    private void displayHotels() {
        hotelContainer.getChildren().clear();
        
        if (hotels.isEmpty()) {
            Text noHotels = new Text("No hotels found in this category");
            noHotels.setStyle("-fx-fill: #888888; -fx-font-size: 16px;");
            hotelContainer.getChildren().add(noHotels);
            return;
        }
        
        for (Hotel hotel : hotels) {
            HBox hotelCard = createHotelCard(hotel);
            hotelContainer.getChildren().add(hotelCard);
        }
    }
    
    private HBox createHotelCard(Hotel hotel) {
        HBox card = new HBox(20);
        card.setAlignment(Pos.CENTER_LEFT);
        card.setStyle("-fx-background-color: #2a2a2a; -fx-background-radius: 10px; -fx-padding: 20px; -fx-cursor: hand;");
        card.setPrefHeight(150);
        
        ImageView imageView = new ImageView();
        try {
            Image image = new Image(hotel.getImageUrl(), true);
            imageView.setImage(image);
        } catch (Exception e) {
            System.err.println("Error loading image: " + e.getMessage());
        }
        imageView.setFitWidth(200);
        imageView.setFitHeight(120);
        imageView.setPreserveRatio(true);
        imageView.setStyle("-fx-background-radius: 8px;");
        
        VBox info = new VBox(8);
        info.setAlignment(Pos.CENTER_LEFT);
        
        Text name = new Text(hotel.getName());
        name.setStyle("-fx-fill: #ffffff; -fx-font-size: 20px; -fx-font-weight: bold;");
        
        Text location = new Text("📍 " + hotel.getLocation());
        location.setStyle("-fx-fill: #cccccc; -fx-font-size: 14px;");
        
        Text price = new Text("₱" + String.format("%.2f", hotel.getPrice()) + " / night");
        price.setStyle("-fx-fill: #66bb6a; -fx-font-size: 16px; -fx-font-weight: bold;");
        
        Button viewButton = new Button("View Details");
        viewButton.setStyle("-fx-background-color: #4da6ff; -fx-text-fill: white; -fx-font-size: 13px; -fx-background-radius: 5px; -fx-padding: 8px 20px; -fx-cursor: hand;");
        viewButton.setOnAction(e -> viewHotelDetails(hotel, e));
        
        info.getChildren().addAll(name, location, price, viewButton);
        
        card.getChildren().addAll(imageView, info);
        
        return card;
    }
    
    private void viewHotelDetails(Hotel hotel, ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/views/HotelDetails.fxml"));
            Parent root = loader.load();
            
            HotelDetailsController controller = loader.getController();
            controller.receiveData(hotel);
            
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
        } catch (Exception e) {
            System.err.println("Navigation error: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    @FXML
    public void handleBack(ActionEvent event) {
        NavigationHelper.navigateTo("/views/MoodSelection.fxml", event);
    }
}
