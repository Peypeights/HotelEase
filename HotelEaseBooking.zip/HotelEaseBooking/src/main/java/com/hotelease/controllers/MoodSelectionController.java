package com.hotelease.controllers;

import com.hotelease.helpers.NavigationHelper;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.input.MouseEvent;
import javafx.scene.Node;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;

public class MoodSelectionController {
    
    @FXML
    public void handleBack(ActionEvent event) {
        NavigationHelper.navigateTo("/views/MainMenu.fxml", event);
    }
    
    @FXML
    public void handleUrbanComfort(MouseEvent event) {
        navigateToHotelList("Urban Comfort", event);
    }
    
    @FXML
    public void handleCoastalEscape(MouseEvent event) {
        navigateToHotelList("Coastal Escape", event);
    }
    
    @FXML
    public void handleNatureRetreat(MouseEvent event) {
        navigateToHotelList("Nature Retreat", event);
    }
    
    private void navigateToHotelList(String mood, MouseEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/views/HotelList.fxml"));
            Parent root = loader.load();
            
            HotelListController controller = loader.getController();
            controller.receiveData(mood);
            
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
        } catch (Exception e) {
            System.err.println("Navigation error: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
