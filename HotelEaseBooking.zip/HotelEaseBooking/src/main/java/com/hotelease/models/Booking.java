package com.hotelease.models;

public class Booking {
    private String bookingId;
    private String hotelId;
    private String hotelName;
    private String customerName;
    private String customerContact;
    private String checkInDate;
    private String checkOutDate;
    private int numberOfNights;
    private double totalPrice;

    public Booking(String bookingId, String hotelId, String hotelName, String customerName, 
                   String customerContact, String checkInDate, String checkOutDate, 
                   int numberOfNights, double totalPrice) {
        this.bookingId = bookingId;
        this.hotelId = hotelId;
        this.hotelName = hotelName;
        this.customerName = customerName;
        this.customerContact = customerContact;
        this.checkInDate = checkInDate;
        this.checkOutDate = checkOutDate;
        this.numberOfNights = numberOfNights;
        this.totalPrice = totalPrice;
    }

    public String getBookingId() {
        return bookingId;
    }

    public void setBookingId(String bookingId) {
        this.bookingId = bookingId;
    }

    public String getHotelId() {
        return hotelId;
    }

    public void setHotelId(String hotelId) {
        this.hotelId = hotelId;
    }

    public String getHotelName() {
        return hotelName;
    }

    public void setHotelName(String hotelName) {
        this.hotelName = hotelName;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getCustomerContact() {
        return customerContact;
    }

    public void setCustomerContact(String customerContact) {
        this.customerContact = customerContact;
    }

    public String getCheckInDate() {
        return checkInDate;
    }

    public void setCheckInDate(String checkInDate) {
        this.checkInDate = checkInDate;
    }

    public String getCheckOutDate() {
        return checkOutDate;
    }

    public void setCheckOutDate(String checkOutDate) {
        this.checkOutDate = checkOutDate;
    }

    public int getNumberOfNights() {
        return numberOfNights;
    }

    public void setNumberOfNights(int numberOfNights) {
        this.numberOfNights = numberOfNights;
    }

    public double getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(double totalPrice) {
        this.totalPrice = totalPrice;
    }

    public String toCSV() {
        return bookingId + "," + hotelId + "," + hotelName + "," + customerName + "," + 
               customerContact + "," + checkInDate + "," + checkOutDate + "," + 
               numberOfNights + "," + totalPrice;
    }
}
