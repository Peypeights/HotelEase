# HoteLease - Philippine Hotel Booking Application

## Overview
HoteLease is a JavaFX desktop application for browsing and booking hotels in the Philippines. The app organizes hotels by mood categories and provides both guest and admin functionality.

## Architecture
- **Language**: Java 11 with JavaFX 17
- **Build Tool**: Maven
- **Design Pattern**: MVC (Model-View-Controller)
- **Data Storage**: CSV files (no database required)

## Project Structure
```
src/main/java/com/hotelease/
├── Main.java                    # Application entry point
├── controllers/                 # UI controllers for each screen
│   ├── LoginController.java
│   ├── MainMenuController.java
│   ├── MoodSelectionController.java
│   ├── HotelListController.java
│   ├── HotelDetailsController.java
│   ├── FavoritesController.java
│   └── AdminController.java
├── models/                      # Data models
│   ├── Hotel.java
│   ├── Booking.java
│   └── User.java
└── helpers/                     # Utility classes
    ├── CSVReader.java           # CSV data operations
    ├── NavigationHelper.java    # Screen navigation
    └── SessionManager.java      # User session management

src/main/resources/
└── views/                       # FXML UI files
    ├── Login.fxml
    ├── MainMenu.fxml
    ├── MoodSelection.fxml
    ├── HotelList.fxml
    ├── HotelDetails.fxml
    ├── Favorites.fxml
    └── Admin.fxml

data/                            # CSV data files (project root)
├── hotels.csv                   # Hotel database
└── bookings.csv                 # Booking records
```

## Features

### User Roles
1. **Guest Access**: Browse hotels, view details, save favorites, and make bookings
2. **Admin Access**: All guest features plus manage hotels and view all bookings
   - Username: `admin`
   - Password: `Admin123`

### Mood Categories
- **Urban Comfort**: Modern city hotels in Metro Manila
- **Coastal Escape**: Beach resorts in Boracay, Palawan, Siargao, etc.
- **Nature Retreat**: Mountain and countryside stays in Tagaytay, Baguio, etc.

### Guest Features
- Browse hotels by mood category
- View detailed hotel information with images
- Save favorite hotels
- Book hotels with customer information and date selection
- Automatic price calculation based on number of nights

### Admin Features
- View all customer bookings
- Add new hotels to the system
- Remove existing hotels
- Manage hotel inventory across all categories

## Data Files

### hotels.csv
Contains 15 Philippine hotels with fields:
- id, name, location, price, moodCategory, imageUrl

### bookings.csv
Stores customer bookings with fields:
- bookingId, hotelId, hotelName, customerName, customerContact, checkInDate, checkOutDate, numberOfNights, totalPrice

## UI Theme
Dark theme with:
- Background: #1a1a1a
- Cards/Panels: #2a2a2a
- Primary Blue: #4da6ff
- Success Green: #66bb6a
- Error Red: #ff4444

## Technical Notes

### CSV Data Persistence
- CSV files stored in `data/` directory at project root
- Static initializer in CSVReader ensures files exist on app startup
- Initial hotel data embedded in code, created automatically if missing
- Works correctly in Replit VNC environment with Maven workflow
- **Assumption**: Application runs from project root directory

### Future Enhancements (Non-blocking)
- CSV field escaping for comma-containing user input
- User-home directory storage for JAR distribution
- Input validation for admin hotel management

## Recent Changes
- Initial project setup (Nov 15, 2025)
- Created complete MVC architecture with 7 screens
- Implemented dark theme UI across all views
- Added CSV-based data persistence with automatic file initialization
- Configured Maven build with JavaFX 17 dependencies
- Installed X11, Mesa, GTK3 system dependencies for VNC display
- Fixed CSV persistence to use filesystem paths (data/ directory)
- Application running successfully in Replit VNC environment
